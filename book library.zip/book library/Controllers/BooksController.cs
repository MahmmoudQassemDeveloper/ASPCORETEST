﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using book_library.Models;

namespace book_library.Controllers
{
    [Route("[controller]")]
    [Route("[controller]/[action]")]
    [ApiController]
    public class BooksController : ControllerBase
    {

        // getting the 'AccessBook' model for add edit delete and search
        static AccessBook accessBook = new AccessBook();

        [HttpGet]
        public Dictionary<string, object> GetBooks()
        {
            // add some books
            accessBook.AddNewBook(new Book()
            {
                Title = "PHP",
                Author = "Mahmmoud",
                Description = "This book for learn the php language",
                Year = 2015
            });

            accessBook.AddNewBook(new Book()
            {
                Title = "C#",
                Author = "Ahmed",
                Description = "This book for learn the C# language lol",
                Year = 2012
            });

            accessBook.AddNewBook(new Book()
            {
                Title = "Paython",
                Author = "Ahmed",
                Description = "This book for learn the Paython language lol",
                Year = 2012
            });

            // will getting the books
            List<Book> books = accessBook.GetAllBooks();
            // result
            return Json.display("We founded some books", true, books);
        }

        public Dictionary<string, object> GetLibDetails()
        {
            libDetails libDetails = new libDetails();
            libDetails.TotalBooks = "total number of books : " + accessBook.GetTotalBooks();
            libDetails.TotalAuthors = "total number of Authors : " + accessBook.GetTotalAuthors();
            // result
            return Json.display("Library Details : ", true, libDetails);
        }

        [HttpPost]
        public Dictionary<string, object> AddBook(string Title, string Author, string Description, int Year)
        {

            if(Title == null)
            {
                // result
                return Json.display("Please Enter The Book Title", false, null);
            }
            else if (Author == null)
            {
                // result
                return Json.display("Please Enter The Book Author", false, null);
            }
            else if (Year.ToString() == null)
            {
                // result
                return Json.display("Please Enter The Book Year", false, null);
            }
            else
            {
                accessBook.AddNewBook(new Book()
                {
                    Title = Title,
                    Author = Author,
                    Description = Description,
                    Year = Year
                });
                // result
                return Json.display("Added the book successfull.!", false, null);
            }
        }

        [HttpPost]
        public Dictionary<string, object> UpdateBook(int? id, string Title, string Author, string Description, int Year)
        {
            // get the book
            var book = accessBook.GetBookById(id);
            if(book == null)
            {
                return Json.display("We can't found the book with id : " + id, false, null);
            }
            else
            {
                book.Title = Title;
                book.Description = Description;
                book.Author = Author;
                book.Year = Year;
                return Json.display("The book was updated successfull .!", false, book);
            }
        }

        [HttpPost]
        public Dictionary<string, object> DeleteBook(int? id)
        {
            var book = accessBook.GetBookById(id);
            if(book == null)
            {
                return Json.display("We can't found the book with id : " + id, false, null);
            }
            else
            {
                accessBook.DeleteBook(id);
                return Json.display("The book was deleted successfull", false, null);
            }
        }

        [HttpPost]
        public Dictionary<string, object> SearchBookByTitle(string sometext)
        {
            List<Book> books = accessBook.GetBookByTitle(sometext);
            if(books.Count > 0)
            {
                return Json.display("We found some books with : " + sometext, true, books);
            }
            else
            {
                return Json.display("We can't found the books", false, null);
            }
        }

        [HttpPost]
        public Dictionary<string, object> SearchBookByDesc(string sometext)
        {
            List<Book> books = accessBook.GetBookByDesc(sometext);
            if (books.Count > 0)
            {
                return Json.display("We found some books with : " + sometext, true, books);
            }
            else
            {
                return Json.display("We can't found the books", false, null);
            }
        }

        [HttpPost]
        public Dictionary<string, object> SearchBookByAuthor(string sometext)
        {
            List<Book> books = accessBook.GetBookByAuthor(sometext);
            if (books.Count > 0)
            {
                return Json.display("We found some books with : " + sometext, true, books);
            }
            else
            {
                return Json.display("We can't found the books", false, null);
            }
        }

    }
}