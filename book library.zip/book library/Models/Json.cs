﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace book_library.Models
{
    public class Json
    {
        public static Dictionary<string, object> display(string message, bool status, object data)
        {
            Dictionary<string, object> resultObt = new Dictionary<string, object>();

            resultObt.Add("message", message);
            resultObt.Add("status", status);
            resultObt.Add("data", data);

            return resultObt;
        }
    }
}
