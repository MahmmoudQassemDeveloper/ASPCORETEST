﻿using System;

namespace book_library.Models
{
    public class libDetails
    {
        public string TotalBooks { get; set; }
        public string TotalAuthors { get; set; }
    }
}
