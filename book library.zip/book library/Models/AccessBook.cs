﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace book_library.Models
{
    public class AccessBook
    {

        // we using books variable to insert books in it
        public static List<Book> ListOfbooks = new List<Book>();

        // Get All books
        public List<Book> GetAllBooks()
        {
            return ListOfbooks.ToList();
        }

        // add new book
        public bool AddNewBook(Book book)
        {
            if (null != book)
            {
                book.ID = ListOfbooks.Count + 1;
                ListOfbooks.Add(book);
                return true;
            }
            return false;
        }

        // Update book
        public bool UpdateBook(Book book)
        {
            // get the book by id
            Book __book = ListOfbooks.Where(b => b.ID == book.ID).FirstOrDefault();
            // we found the book
            if (null != __book)
            {
                __book.Title = book.Title;
                __book.Description = book.Description;
                __book.Author = book.Author;
                return true;
            }
            return false;
        }

        // Delete book
        public void DeleteBook(int? id)
        {
            // user added the id
            if (null != id)
            {
                // getting the book by id
                var book = ListOfbooks.Where(b => b.ID == id).FirstOrDefault();
                // removing the book
                ListOfbooks.Remove(book);
            }
        }

        // Search in books by title
        public List<Book> GetBookByTitle(string title)
        {
            List<Book> books = ListOfbooks.Where(t => t.Title.IndexOf(title) > -1).ToList();
            return books;
        }

        // Search in books by description
        public List<Book> GetBookByDesc(string Description)
        {
            List<Book> books = ListOfbooks.Where(d => d.Description.IndexOf(Description) > -1).ToList();
            return books;
        }

        // Search in books by author
        public List<Book> GetBookByAuthor(string Author)
        {
            List<Book> books = ListOfbooks.Where(a => a.Author.IndexOf(Author) > -1).ToList();
            return books;
        }

        // get book by id
        public Book GetBookById(int? id)
        {
            return ListOfbooks.Where(x => x.ID == id).FirstOrDefault();
        }

        // get total books
        public int GetTotalBooks()
        {
            return ListOfbooks.Count;
        }

        // get Authors 
        public int GetTotalAuthors()
        {
            List<string> auhs = new List<string>();
            int total = 0;
            foreach(Book book in ListOfbooks)
            {
                if(!auhs.Contains(book.Author))
                {
                    total += 1;
                    auhs.Add(book.Author);
                }
            }

            return total;
        }
    }
}